package com.example.TaskManagementToolss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementToolssApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagementToolssApplication.class, args);
	}

}
