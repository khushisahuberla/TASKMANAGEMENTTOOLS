package com.example.TaskManagementToolss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagementToolssApplicationTests {

	@Test
	void contextLoads() {
	}

}
